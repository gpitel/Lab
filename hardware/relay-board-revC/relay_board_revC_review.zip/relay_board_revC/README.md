# OpenMagnetics relay board rev C -- review package (2026-10-13)

Sent for an opinion before ordering. The layout is complete; the open points are listed below.

## State

- Schematic: ERC 0; netlist truth-table check passes (19 configurations x 2-wire/Kelvin,
  calibration standards, supervisory nets).
- Board: every net routed, on the two outer layers only. DRC: 0 unconnected, 0 clearance
  violations, 0 shorts (`reports/relay_board_drc.txt`, error severity; warnings are listed below).
- 4 layers, JLC04161H-7628 (SIG / GND / GND / SIG), 174 x 110 mm, all vias 0.3 / 0.6 mm, none in
  an SMD pad. No dangling track or via.

## What the design is

`docs/ARCHITECTURE.md` is the design intent and the point-by-point response to the review of
rev B: Kelvin force/sense through every relay (pole 1 force, pole 2 sense), direct link relays,
a standards column (100R LOAD, 1R and 10 pF check standards, each sensed at its pads), a
difference front-end switched onto CH1, end-fed rails (equal HI + LO length for every column:
182.8 mm for all four), one unified ground with all cables on one edge.
`docs/EMC_COMPLIANCE.md` is the EN 61326-1 plan.

Planes: the inner layers carry no tracks. They are solid ground everywhere except openings that
follow the copper of the nodes that can float at an intermediate potential (terminal buses, clip
arms, clips; 0.75 mm margin, with 1 mm ground bridges so no ground is left as an island), where
ground capacitance is a DUT-dependent error. Ground is kept
under the rails, their feeds and the standards column, which always sit at the HI or LO
potential. The outer layers have no pour in the measurement area.

On the remark that the Kelvin lines should be fully coaxial: on a rigid board the force/sense
coupling is fixed geometry, and it is removed by an open/short compensation taken once at the
clip plane and stored per path in the controller (the user only ever clamps the DUT). What no
compensation removes is the ground capacitance of a floating node, hence the openings. A driven
guard under each terminal's lines was simulated (`simulate_guard.py` in the repository): it
leaves ~2 pF below 1 MHz but presents a negative conductance to the winding above (about
-53 kohm at 3 MHz, -5 kohm at 10 MHz), so it was not adopted. The ground capacitance of each
terminal (estimate 6 / 15 / 8 / 8 pF for A / B / C / D) will be measured on the first boards.

DUT interface: Grayhill 02-21 miniature test clips, their banana plugs straight into plated
4.0 mm holes. A Kelvin pair per terminal, force inner and sense outer, 8 mm apart: the DUT lead
passes through the force clip into the sense clip. The bay between the force clips is 41 mm wide.

## Open points (also in docs/TODO.md)

- Force arms of terminals A and C are 24.3 and 23.1 mm (B and D: 13.8 and 15.0 mm): each side
  has two isolation relays between its two clip rows, so one terminal has the far relay. They
  are in the force path only in Kelvin mode and inside the clamp-plane fixture compensation in
  2-wire mode; accepted with a 26 mm budget (`reports/parasitic_report.txt`).
- Force-to-sense magnetic coupling is not removed by Kelvin sensing; see `kelvin_coupling.py`
  in the repository (its geometry predates this layout: indicative only).
- Measurement copper within 1 mm of coil, supply or digital copper: 174 mm in total, worst
  /RAIL_LO 22.1 mm and /SB 21.0 mm (`reports/parasitic_report.txt`).
- Terminal B's bus is 194 mm long (it reaches the link relays on the far side of the standards
  column); calibrated per configuration, but the longest floating node.
- EMC review tool (Faraday, `reports/faraday_summary.txt`): the VBUS TVS is ~9 mm of track from
  the USB-C pin; the relay-drive lanes run as close bundles (static during a measurement).
- DRC warnings left: silkscreen text size / overlap, and the library-footprint notice of the
  cable-edge bonding strip.
- Not yet verified on hardware: front-end common-mode rejection (60 dB is a simulation with
  0.1 % resistors), the Kelvin measurement recipe in the software, the firmware build for the
  reassigned relay pins.

## Contents

- `kicad/` -- KiCad 10 project. Open `relay_board.kicad_pro`.
- `pdf/` -- schematic, board (one page per layer), top/bottom overlay, copper renders.
- `docs/` -- ARCHITECTURE.md, EMC_COMPLIANCE.md, TODO.md, BOM (md + csv).
- `reports/` -- DRC, ERC, parasitic / coupling report, Faraday summary.
- `fab/` -- Gerbers, drill, IPC-356 netlist; `jlc/` -- JLCPCB assembly BOM and placement file.
